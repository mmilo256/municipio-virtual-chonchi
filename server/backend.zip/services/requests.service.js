import { Op } from 'sequelize';
// import { sequelize } from '../config/db/config.js';
import Documento from '../models/Documento.js';
import Tramite from '../models/Tramite.js';
import Solicitud from '../models/Solicitud.js';
import Log from '../models/Log.js';
import Usuario from '../models/Usuario.js';

export const getRequests = async (where = null) => {
  let options = {};
  if (where) {
    options.where = where;
  }
  const requests = await Solicitud.findAll(options);
  return requests;
};

export const getRequestById = async (id) => {
  const request = await Solicitud.findByPk(id, {
    include: [
      {
        model: Tramite,
        attributes: ['titulo'],
      },
    ],
  });
  return request;
};

export const getLogs = async (request_id) => {
  const logs = await Log.findAll({ where: { solicitud_id: request_id } });
  return logs;
};

export const getRequestsByProcedure = async (procedure_id, pageSize, offset, filters, search) => {
  const whereClause = {
    tramite_id: procedure_id,
  };

  // Filtro por estado
  if (filters) {
    const statusArray = filters
      .split(',')
      .map((s) => s.trim())
      .filter(Boolean);
    if (statusArray.length) {
      whereClause.estado = {
        [Op.in]: statusArray,
      };
    }
  }

  // Search por orgName u orgRut
  if (search && search.trim() !== '') {
    const s = search.trim();

    whereClause[Op.or] = [
      { orgName: { [Op.like]: `%${s}%` } },
      { orgRut: { [Op.like]: `%${s}%` } },
    ];
  }

  const { rows, count } = await Solicitud.findAndCountAll({
    limit: pageSize,
    offset,
    where: whereClause,
    include: {
      model: Usuario,
      attributes: ['nombres', 'apellidos', 'run'],
    },
    distinct: true, // importante con include + paginación
  });

  const totalPages = Math.max(1, Math.ceil(count / pageSize));

  return {
    requests: rows,
    totalPages,
  };
};

export const getUserRequests = async (user_id, pageSize, offset) => {
  const { rows, count } = await Solicitud.findAndCountAll({
    limit: pageSize,
    offset,
    where: { usuario_id: user_id },
    order: [['createdAt', 'DESC']],
    include: {
      model: Tramite,
      attributes: ['titulo', 'nombre'],
    },
  });
  const totalPages = Math.ceil(count / pageSize) === 0 ? 1 : Math.ceil(count / pageSize);

  return { requests: rows, totalPages };
};

export const updateRequestStatusService = async (id, status) => {
  try {
    await Solicitud.update({ estado: status }, { where: { id } });
    await Log.create({ estado: status, solicitud_id: id });
    return { message: 'Estado actualizado exitosamente', status, requestId: id };
  } catch (error) {
    throw { error, message: 'No se pudo actualizar el estado de la solicitud' };
  }
};

export const getDocumentsByRequest = async (requestId, type) => {
  try {
    const docs = await Documento.findAll({ where: { solicitud_id: requestId, tipo: type } });
    return docs;
  } catch (error) {
    console.log(error);
    return null;
  }
};

export const uploadDocument = async (file, requestId, status, type, name) => {
  try {
    const doc = {
      ruta: file?.path || null,
      originalname: file?.originalname,
      estado: status || null,
      tipo: type || null,
      nombre: name || 'sin nombre',
      solicitud_id: requestId,
    };
    const newDoc = await Documento.create(doc);
    return newDoc;
  } catch (error) {
    console.log(error);
    throw { status: 500, message: 'No se pudo subir el documento' };
  }
};

export const createNewRequest = async (data) => {
  const requestData = {
    estado: data.estado || 'pendiente', // Establecer el estado inicial de la solicitud
    respuestas: data.respuestas ? JSON.stringify(data.respuestas) : null,
    tramite_id: data.tramite_id,
    usuario_id: data.usuarioId, // Combinar los datos adicionales con los documentos
    funcionario_id: data?.funcionario_id || null,
    origen: data.origen || null,
    orgName: data.respuestas?.orgName || null,
    orgRut: data.respuestas?.orgRut || null,
  };
  try {
    // Crear la solicitud en la base de datos
    const request = await Solicitud.create(requestData);

    // Registrar el estado inicial de la solicitud en el log de estados
    await Log.create({ solicitud_id: request.id, estado: 'pendiente' });
    return request;
  } catch (error) {
    console.error(error);
    throw { status: 500, message: 'No se pudo ingresar la solicitud' };
  }
};

/* export const createNewRequest = async (data, files) => {
  const t = await sequelize.transaction();

  const requestData = {
    estado: 'pendiente', // Establecer el estado inicial de la solicitud
    respuestas: JSON.stringify(data.respuestas),
    tramite_id: data.tramite_id,
    usuario_id: data.usuarioId, // Combinar los datos adicionales con los documentos
  };
  try {
    // Crear la solicitud en la base de datos
    const request = await Solicitud.create(requestData, { transaction: t });

    const documents = files.map((file) => {
      const str = file.fieldname;
      const match = str.match(/\[(.*?)\]/);
      if (match) {
        return {
          ruta: file.path,
          originalname: file.originalname,
          nombre: match[1],
          tipo: 'adjunto',
          solicitud_id: request.id,
        };
      }
    });

    // Guardar documentos adjuntos en base de datos
    await Document.bulkCreate(documents, { transaction: t });

    // Registrar el estado inicial de la solicitud en el log de estados
    await Log.create(
      { solicitud_id: request.id, estado: 'pendiente' },
      { transaction: t },
    );
    await t.commit(); // Confirmar la transacción
    return request;
  } catch (error) {
    console.error(error);
    await t.rollback(); // Si ocurre un error, revertir la transacción
    throw { status: 500, message: 'No se pudo ingresar la solicitud' };
  }
}; */
